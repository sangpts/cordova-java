package vn.edu.greenwich.cw_1_sample.database;

public class BackupEntry {
    public static final String TABLE_NAME = "backup";
}